#!/system/bin/sh
# generate user files in the bootstrap

mkdir -p bootstrap/home/$1
echo "$1:x:$EXTRA_USER_ID:$EXTRA_USER_ID:$1 Linux:/home/$1:/bin/sh" >> bootstrap/etc/passwd